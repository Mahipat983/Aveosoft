import React from 'react';
import Homepage from './Compenent/Homepage'
import { BrowserRouter, Route} from "react-router-dom";
import ProductDes from './Compenent/Product_description'


class App extends React.Component{
  render()
  {
     return(
<BrowserRouter>
        <Route exact path={<Homepage />} component={Homepage}></Route>
     <Route path="/Product_Des/:P_id" component={ProductDes}></Route> 
      
     
    
     
     </BrowserRouter>
      

     )
     
  }
}


export default App;
