import React from 'react'
import Grid from '@material-ui/core/Grid';
import Paper from '@material-ui/core/Paper';
import im1 from '../Image/im1.jpg'
export default class Product_description extends React.Component{
    constructor()
    {
        super()
        
        this.state={
            product:[],
            
    }
}
    componentDidMount()
    {
     fetch('https://aveosoft-react-assignment.herokuapp.com/products')
     .then(res=>res.json())
     .then(res=>this.setState({product:res}))
     
    }
    
    render()
    {
         return(
             <div>
                
                 <Grid container justify="center">
                <Grid item xl={12} align="center" >
               <Grid container  justify="center">
                 
                 {
                 this.state.product.map((p)=>
                
                     p.id==this.props.match.params.P_id?(
                       
                        <Paper style={{width:'800px',height:'500px',marginTop:'70px'}} align="center"> 
                        <table cellSpacing="5">
                            
                              <tr>
                                
                                <td rowSpan="10" ><img src={im1} style={{height:'350px'}} /></td>
                            </tr>
                            
                            <tr>
                                <th>Name:</th>
                                <td>{p.name}</td>
                            </tr>
                            <br/>
                            <tr>
                            <th>Model:</th>
                                <td>{p.model}</td>
                            </tr>
                            <br/>
                            <tr>
                            <th>Price:</th>
                                <td>{p.price}</td>
                            </tr>
                            <br/>
                            <tr>
                            <th>Description:</th>
                                <td align="justify">{p.description}</td>
                            </tr>
                        </table>
                        </Paper>
                         
                         
                     ):(null)
                 
                 )
                 
                  
                  
                 }
                 </Grid>
                 </Grid>
                 </Grid>
                 
             </div>
         )
    }
}
