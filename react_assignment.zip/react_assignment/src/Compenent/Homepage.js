import React from 'react'
import Select from '@material-ui/core/Select';
import Paper from '@material-ui/core/Paper';
import Grid from '@material-ui/core/Grid';
import FormControl from '@material-ui/core/FormControl';
import im1 from '../Image/im1.jpg'
class Homepage extends React.Component{
    constructor()
    {
        super();
        this.state={
        category:[],
        product:[],
        disProduct:true
        }

    }
    componentDidMount()
    {
     fetch('https://aveosoft-react-assignment.herokuapp.com/categories')
     .then(res=>res.json())
     .then(res=>this.setState({category:res}))

     fetch('https://aveosoft-react-assignment.herokuapp.com/products')
     .then(res=>res.json())
     .then(res=>this.setState({product:res}))
    }
    
   SelectCategory=(e)=>
   {
       this.setState({cat:e.target.value})
   
   } 
    
    render(){
       {}
        return(
           
           <div>
              
             
               <br/>
               <br/>
           
             <table align="center" cellPadding="8">
                 <tr>
                     <th>Select Category</th>
                     <td>
                      <FormControl> 
                     
                     <Select
                      
                   variant='outlined'
                   native
                  
                   onChange={this.SelectCategory}
                   style={{width:'120px'}}
                    >
                  <option  value="Category">Category</option>  
                      
                  {
                   this.state.category.map((ct)=>
                   
                   <option value={ct.id}>{ct.name}</option>
                   )
                }
                </Select>
                </FormControl>
                     </td>
                 </tr>
             </table>
            
             
             <Grid container justify="center">
            <Grid item sm={6} align="center" >
           <Grid container>
         
         {
              this.state.product.map((pr)=>
              
              this.state.cat==pr.categoryId?(
                this.state.disProduct=false,
              <Paper style={{marginLeft:'30px',width:'180px',height:'250px',marginTop:'50px'}}
              onClick={()=>{this.props.history.push('./Product_Des/'+pr.id)}}>
              <table>
              <tr>
                        <td colSpan="10"> <img src={im1} style={{width:'135px'}}/></td>
                    </tr>
                  
                  <tr>
                      <th>Name:</th><th>{pr.name}</th>
                  </tr>
                  <tr>
                      <th>model:</th><th>{pr.model}</th>
                  </tr>
                  <tr>
                      <th>price:</th><th>{pr.price}</th>
                  </tr>
              </table>
               </Paper>
               ):(this.state.disProduct || this.state.cat=='Category'?(
                <Paper style={{marginLeft:'30px',width:'180px',height:'250px',marginTop:'50px'}}
                onClick={()=>{this.props.history.push('./Product_Des/'+pr.id)}}>
                <table>
                    
                    <tr>
                        <td colSpan="10"> <img src={im1} style={{width:'135px'}}/></td>
                    </tr>
                   
                    <tr>
                        <th>Name:</th><th>{pr.name}</th>
                    </tr>
                    <tr>
                        <th>model:</th><th>{pr.model}</th>
                    </tr>
                    <tr>
                        <th>price:</th><th>{pr.price}</th>
                    </tr>
                </table>
                 </Paper>

               ):(null))
          
              )
          }
               
          
                  
          
        </Grid>
      </Grid>
    </Grid>
 
          
         </div>
        )
    }
}
export default Homepage;